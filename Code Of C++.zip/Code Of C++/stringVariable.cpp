#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    char name[15] = "Noushin Mishti";
    cout<< "my name is: " <<name;

    getch();
}
