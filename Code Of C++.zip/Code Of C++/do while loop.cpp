#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int i=5;

    do{
        cout<<"Abir"<<endl;
        i--;
    }
    while(i>=1);

    cout<<"end of while loop";

    getch();
}
