#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int num1,num2,sum;
cout<<"Enter The 2 number: ";
cin>>num1>>num2;

sum=num1+num2;
cout<<" The Sum is: "<<sum;

getch();









}