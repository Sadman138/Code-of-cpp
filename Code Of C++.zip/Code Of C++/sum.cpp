#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
  int num1=10,num2=20;

  int sum = num1 + num2;

  cout<<"sum is: " <<sum;

  getch();
}
