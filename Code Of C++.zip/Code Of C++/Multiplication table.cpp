#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int num,i,result;
cout << "Enter The Number" << endl;
cin>>num;
for(i=1;i<=10;i++){

result=(num*i);
cout << num << " X " << i << "=" <<  result ;

}
cout << num << " X " << i << "=" <<  result ;
}