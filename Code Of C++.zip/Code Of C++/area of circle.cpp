#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int radius,result;
float pi=3.1416;;
cout<<"Enter The value radius: ";
cin>>radius;
result=pi*(radius*radius);
cout<<" The area of circle: " <<result;



}