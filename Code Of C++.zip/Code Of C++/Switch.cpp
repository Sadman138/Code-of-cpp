#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int digit;
cout << "Enter The digit" << endl;
cin>>digit;
switch(digit){
case 0:
cout << "Zero" ;
break;


case 1:
cout << "One" << endl;
break;
case 2:int year;
cout <<"Two";
break;

case 3:
cout << "Three" ;
break;


default:
cout << "Not a digit" << endl;













}




}