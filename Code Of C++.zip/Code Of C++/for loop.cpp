#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    for(int i=1;i<100;i++)
    {
        cout<<"Allah"<<endl;
    }
    getch();
}
