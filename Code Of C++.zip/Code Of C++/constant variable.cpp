#include<iostream>
#include "myClassDemo.h"

using namespace std;

int main()
{
    const myClassDemo ob;
    ob.display1();

    return 0;
}
