#include<iostream>
#include<conio.h>
using namespace std;
int addition(int a,int b){
int sum=a+b;
return sum;
}
int main(){
addition(10,20);



cout<<"sum= " <<addition(10,20)<< endl;



}