#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int marks;
cout << "Enter any number" << endl;
cin>>marks;
if(marks>=33){
cout<<"passed"<<endl;
}
else{
cout<<"failed"<<endl;
}


}