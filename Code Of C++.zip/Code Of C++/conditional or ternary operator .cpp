#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int num;
cin >>num;
(num%2)?cout << num <<" is even " : cout << "odd Number" << endl;


}











