#include<iostream>
#include<conio.h>
using namespace std;

class student{
public:
int id;
double cgpa;




};


int main(){

student sadman;
sadman.id=24;
sadman.cgpa=3.75;

cout <<sadman.id<< " "<<sadman.cgpa << endl;


student safat;
safat.id=25;
safat.cgpa=3.75;
cout <<safat.id <<" "<<safat.cgpa << endl;








}