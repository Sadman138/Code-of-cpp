#include<iostream>
#include<stdio.h>
#include<conio.h>
using namespace std;
int x=20;
int main(){
int x=10;
cout << ::x << endl;

}