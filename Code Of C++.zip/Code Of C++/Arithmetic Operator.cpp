#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int num1=50,num2=25;

    int sum = num1+num2;
    cout<<"the sum is: " <<sum<<endl;

    int sub = num2-num1;
    cout<<"the sub is: " <<sub<<endl;

    int mul = num1*num2;
    cout<<"the multiplication is: " <<mul<<endl;

    int div = num2/num1;
    cout<<"the division is: " <<div<<endl;

    getch();
}
