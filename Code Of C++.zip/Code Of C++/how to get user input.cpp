#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int num1,num2;

  cout<<"enter two numbers: ";
  cin>>num1 >>num2;

  int sum = num1 + num2;

  cout<<"sum is: " <<sum;

  getch();
}
