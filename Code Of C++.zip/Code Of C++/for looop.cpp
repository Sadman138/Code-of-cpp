#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int i,num;
cout << "Entee the num" << endl;
cin >> num;
for(i=0;i<num;i++){

cout << "Bangladesh " << endl;

}

}