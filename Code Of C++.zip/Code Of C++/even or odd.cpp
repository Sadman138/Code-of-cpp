#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int num;
cout << "Enter any number" << endl;
cin>>num;
if(num%2==0){
cout<<"even number"<<endl;
}
else{
cout<<"odd number"<<endl;
}


}