#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int marks[5] = {55,45,35,25,15};

    for(int i=0; i<5;i++)
    {
        cout<<marks[i]<<" ";
    }
    getch();
}
