#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num1=10,num2=30;
    char ch;
    ch='A';

    cout<<"Number1 = "<<num1<<endl <<"Number2 = "<<num2<<endl;
    cout<<"character = "<<ch;

    getch();
}
