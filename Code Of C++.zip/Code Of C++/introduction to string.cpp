#include<iostream>
#include<conio.h>
using namespace std;

int main()

{
    char message[6]={'h','e','l','l','o'};
    cout<<message[2];

    getch();
}
