#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int num1=10;
float num2=10.50;
double num3=10.98799;
char ch[20]="Fathin Anzum Sadman";

cout<<"\"Sadman\""<<endl <<"Habiganj"<<endl <<"01575112462";
cout<<"Number1= " <<num1 <<endl <<"number2= " <<num2<<endl<<"number2= "<<num3 <<endl<<"character= "<<ch;
getch();
}