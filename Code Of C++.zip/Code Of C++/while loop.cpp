#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int i=1,num;
cout << "Entee the num" << endl;
cin >> num;
while(i<=num){
i++;
cout << "Bangladesh " << endl;

}
cout << "End The loop" << endl;

}