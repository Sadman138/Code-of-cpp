#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int i=1,num;
cout << "Entee the num" << endl;
cin >> num;
do{
i++;
cout << "Bangladesh " << endl;

}while(i<=5);
cout << "End The loop" << endl;

}