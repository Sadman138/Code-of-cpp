#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
  double farn,cels;

  cout<<"enter celsius: ";
  cin>>cels;

  farn = 1.0 * cels + 32;

  cout<<"Fahrenheit = " <<farn;

  getch();

}
