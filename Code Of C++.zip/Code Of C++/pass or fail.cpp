#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int mark;
    cout<<"enter your marks: ";
    cin>>mark;

    if(mark>=33)
    {
        cout<<"pass";
    }
    else
    {
        cout<<"fail";
    }
    getch();
}
