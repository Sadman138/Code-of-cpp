#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int num1,num2;
cout << "Enter any number" << endl;
cin>>num1>>num2;
if(num1>num2){
cout<<"Larger number"<<endl;
}
else{
cout<<"small number"<<endl;
}


}