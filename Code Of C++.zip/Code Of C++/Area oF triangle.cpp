#include<iostream>
#include<conio.h>
using namespace std;
int main(){
int height,width,result;
cout<<"Enter The value height & width: ";
cin>>height>>width;
result=0.5*height*width;
cout<<" The area of Triangle: " <<result;








}