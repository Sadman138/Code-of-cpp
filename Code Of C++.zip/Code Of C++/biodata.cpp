#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    cout<< "Noushin Mishti\n";
    cout<< "habiganj\n";
    cout<< "01773385001";

    getch();
}
