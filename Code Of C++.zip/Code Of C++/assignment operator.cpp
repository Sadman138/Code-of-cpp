#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int x=3;

    x+=2;
    cout<<x<<endl;

    x-=2;
    cout<<x<<endl;

    x*=2;
    cout<<x<<endl;

    x%=2;
    cout<<x<<endl;

    getch();
}
