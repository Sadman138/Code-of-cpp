#include<iostream>
#include<stdio.h>
#include<conio.h>
using namespace std;

int main()
{
    char name[20];

    cout<<"enter your name: ";
    gets(name);

    cout<<" welcome " <<name;

    getch();
}
